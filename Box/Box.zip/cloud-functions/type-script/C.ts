export class C {
    //store
    public static readonly NUM_NEARBY_STORES = 20;
    public static readonly NUM_NEARBY_STORES_BY_KEYWORDS = 5;
    public static readonly NUM_NEARBY_STORES_BY_PRODUCTS = 5;
    public static readonly NUM_STORES_BY_KEYWORDS = 20;
    public static readonly NUM_STORES_PER_QUERY = 50;
    public static readonly NUM_COMMENTS = 20;
    //product
    public static readonly NUM_NEARBY_PRODUCTS = 20;
    public static readonly NUM_PRODUCTS_OF_STORE = 20;
    public static readonly NUM_PRODUCTS_BY_KEYWORDS = 20;
    public static readonly NUM_PRODUCTS_PER_QUERY = 50;
    public static readonly NEARBY_DIMEN = 1; //km
}
