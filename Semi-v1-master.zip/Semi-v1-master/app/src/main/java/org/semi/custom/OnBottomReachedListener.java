package org.semi.custom;

public interface OnBottomReachedListener<T> {
    public void onBottomReached(T obj, int position);
}
