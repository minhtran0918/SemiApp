package org.semi.custom;

public interface OnItemClickListener<T> {
    public void onItemClick(T obj);
}
