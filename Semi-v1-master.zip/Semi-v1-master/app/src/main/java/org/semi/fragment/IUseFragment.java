package org.semi.fragment;

import android.support.v4.app.Fragment;

public interface IUseFragment {
    public void onFragmentAttached(Fragment fragment);
}
