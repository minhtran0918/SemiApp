package org.semi.sqlite;

import android.content.ContentValues;

public interface IInsertion {
    public ContentValues getContentFromArray(String[] arr);
}
